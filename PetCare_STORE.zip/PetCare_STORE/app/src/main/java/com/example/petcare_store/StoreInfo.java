package com.example.petcare_store;

public class StoreInfo {
    public String storeName;
    public String address;
    public String productName;
    public String productDetail;
    public String imageAd;
    public String imagePromo;
}
